function fnFormatDetails ( oTable, nTr )
{
    var aData = oTable.fnGetData( nTr );
    var sOut = '<table cellpadding="5" cellspacing="0" border="0" style="padding-left:50px;">';
    sOut += '<tr><td>Rendering engine:</td><td>'+aData[1]+' '+aData[4]+'</td></tr>';
    sOut += '<tr><td>Link to source:</td><td>Could provide a link here</td></tr>';
    sOut += '<tr><td>Extra info:</td><td>And any further details here (images etc)</td></tr>';
    sOut += '</table>';

    return sOut;
}

$(document).ready(function() {

    $('#dynamic-table').dataTable({
        "aaSorting": [[ 4, "asc" ]]
    } );
    //$('#dynamic-table-backGroundColor').dataTable({
    //    "aaSorting": [[4, "asc"]]
    //});
    $('#dynamic-table-sc_master').dataTable({
        "aaSorting": [[4, "asc"]]
    });
    $('#dynamic-table-sc_store').dataTable({
        "aaSorting": [[4, "asc"]]
    });
    $('#dynamic-table-Graphics-Kit-Extra').dataTable({
        "aaSorting": [[4, "asc"]]
    });
    $('#dynamic-table-businessMarketingBanner').dataTable({
        "aaSorting": [[4, "asc"]]
    });
    $('#dynamic-table-graphicsSkit').dataTable({
        "aaSorting": [[4, "asc"]]
    });
    $('#dynamic-table-bikeBrand').dataTable({
        "aaSorting": [[4, "asc"]]
    });
    $('#dynamic-table-numberfontplate').dataTable({
        "aaSorting": [[4, "asc"]]
    });
    $('#dynamic-table-vat').dataTable({
        "aaSorting": [[4, "asc"]]
    });
    $('#dynamic-table-storeType').dataTable({
        "aaSorting": [[4, "asc"]]
    });
    $('#dynamic-table-productType').dataTable({
        "aaSorting": [[4, "asc"]]
    });
    $('#dynamic-table-product').dataTable({
        "aaSorting": [[4, "asc"]]
    });
    $('#dynamic-table-proInfo').dataTable({
        "aaSorting": [[4, "asc"]]
    });
    $('#dynamic-table-country_new').dataTable({
        "aaSorting": [[1, "asc"]],
    });
    $('#dynamic-table-state').dataTable({
        "aaSorting": [[4, "asc"]]
    });
    $('#dynamic-table-user').dataTable({
        "aaSorting": [[4, "asc"]]
    });
    $('#dynamic-table-graphics').dataTable({
        "aaSorting": [[4, "asc"]]
    });
    $('#dynamic-table-country').dataTable({
        "aaSorting": [[4, "asc"]]
    });
    $('#dynamic-table-namefont').dataTable({
        "aaSorting": [[4, "asc"]]
    });
    $('#dynamic-table-numberfont').dataTable({
        "aaSorting": [[4, "asc"]]
    });
    $('#dynamic-table-numberplateslogos').dataTable({
        "aaSorting": [[4, "asc"]]
    });
    $('#dynamic-table-graphicskit').dataTable({
        "aaSorting": [[4, "asc"]]
    });
    $('#dynamic-table-homeBanner').dataTable({
        "aaSorting": [[4, "asc"]]
    });
    $('#dynamic-table-screenPrintingBanner').dataTable({
        "aaSorting": [[4, "asc"]]
    });
    $('#dynamic-table-customGraphicBanner').dataTable({
        "aaSorting": [[4, "asc"]]
    });
    $('#dynamic-table-paymenthistory').dataTable({
        "aaSorting": [[4, "asc"]]
    })
    $('#dynamic-table-shippingtax').dataTable({
        "aaSorting": [[4, "asc"]]
    })
    /*
     * Insert a 'details' column to the table
     */
    var nCloneTh = document.createElement( 'th' );
    var nCloneTd = document.createElement( 'td' );
    nCloneTd.innerHTML = '<img src="images/details_open.png">';
    nCloneTd.className = "center";

    $('#hidden-table-info thead tr').each( function () {
        this.insertBefore( nCloneTh, this.childNodes[0] );
    } );

    $('#hidden-table-info tbody tr').each( function () {
        this.insertBefore(  nCloneTd.cloneNode( true ), this.childNodes[0] );
    } );

    /*
     * Initialse DataTables, with no sorting on the 'details' column
     */
    var oTable = $('#hidden-table-info').dataTable( {
        "aoColumnDefs": [
            { "bSortable": false, "aTargets": [ 0 ] }
        ],
        "aaSorting": [[1, 'asc']]
    });

    /* Add event listener for opening and closing details
     * Note that the indicator for showing which row is open is not controlled by DataTables,
     * rather it is done here
     */
    $(document).on('click','#hidden-table-info tbody td img',function () {
        var nTr = $(this).parents('tr')[0];
        if ( oTable.fnIsOpen(nTr) )
        {
            /* This row is already open - close it */
            this.src = "images/details_open.png";
            oTable.fnClose( nTr );
        }
        else
        {
            /* Open this row */
            this.src = "images/details_close.png";
            oTable.fnOpen( nTr, fnFormatDetails(oTable, nTr), 'details' );
        }
    } );
} );