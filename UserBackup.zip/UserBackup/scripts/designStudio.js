/**
 * Third party stuff, leave the license in tact
 */

/* jQuery-FontSpy.js v3.0.0
 * https://github.com/patrickmarabeas/jQuery-FontSpy.js
 *
 * Copyright 2013, Patrick Marabeas http://pulse-dev.com
 * Released under the MIT license
 * http://opensource.org/licenses/mit-license.php
 *
 * Date: 02/11/2015
 */

(function (w, $) {

    fontSpy = function (fontName, conf) {
        var $html = $('html'),
            $body = $('body'),
            fontFamilyName = fontName;

        // Throw error if fontName is not a string or not is left as an empty string
        if (typeof fontFamilyName !== 'string' || fontFamilyName === '') {
            throw 'A valid fontName is required. fontName must be a string and must not be an empty string.';
        }

        var defaults = {
            font: fontFamilyName,
            fontClass: fontFamilyName.toLowerCase().replace(/\s/g, ''),
            success: function () { },
            failure: function () { },
            testFont: 'Courier New',
            testString: 'QW@HhsXJ',
            glyphs: '',
            delay: 50,
            timeOut: 1000,
            callback: $.noop
        };

        var config = $.extend(defaults, conf);

        var $tester = $('<span>' + config.testString + config.glyphs + '</span>')
            .css('position', 'absolute')
            .css('top', '-9999px')
            .css('left', '-9999px')
            .css('visibility', 'hidden')
            .css('fontFamily', config.testFont)
            .css('fontSize', '250px');

        $body.append($tester);

        var fallbackFontWidth = $tester.outerWidth();

        $tester.css('fontFamily', config.font + ',' + config.testFont);

        var failure = function () {
            $html.addClass("no-" + config.fontClass);
            if (config && config.failure) {
                config.failure();
            }
            config.callback(new Error('FontSpy timeout'));
            $tester.remove();
        };

        var success = function () {
            config.callback();
            $html.addClass(config.fontClass);
            if (config && config.success) {
                config.success();
            }
            $tester.remove();
        };

        var retry = function () {
            setTimeout(checkFont, config.delay);
            config.timeOut = config.timeOut - config.delay;
        };

        var checkFont = function () {
            var loadedFontWidth = $tester.outerWidth();

            if (fallbackFontWidth !== loadedFontWidth) {
                success();
            } else if (config.timeOut < 0) {
                failure();
            } else {
                retry();
            }
        }

        checkFont();
    }
})(this, jQuery);


/**
 *  Our stuff starts here
 */

function $ds(config) {

    config.layers.reverse();

    // lookups
    var layersToIdx = {};
    var swatchToLayers = [];
    var labelToSelect = {};
    var labelToText = {};
    var studio_id = makeid();
    var parentDiv = $("<div id='design_studio_" + studio_id + "' class='design_studio'>");
    var selected_colorway = -1;
    var colorwaysToLayers = {};
    var remoteColors = {};
    var remoteBorders = {};
    var colorwayNum = 0;
    var outputLocations = [];
    var savedConfig = {};
    if (localStorage && localStorage.dSSaved) {
        try {
            savedConfig = JSON.parse(localStorage.dSSaved);

            if (savedConfig[config.namespace]) {
                for (var layerIdx = 0; layerIdx < config.layers.length; layerIdx++) {
                    if (savedConfig[config.namespace][config.layers[layerIdx].id]) {
                        if (config.layers[layerIdx].border && savedConfig[config.namespace][config.layers[layerIdx].id].border) {
                            config.layers[layerIdx].border.default_color = savedConfig[config.namespace][config.layers[layerIdx].id].border.default_color;
                            config.layers[layerIdx].border.toggledOn = savedConfig[config.namespace][config.layers[layerIdx].id].border.toggledOn;
                        }
                        config.layers[layerIdx].default_color = savedConfig[config.namespace][config.layers[layerIdx].id].default_color;
                        config.layers[layerIdx].toggledOn = savedConfig[config.namespace][config.layers[layerIdx].id].toggledOn;

                    }
                }
            }
        } catch (e) {
            console.log(e);
            // Just skip it
        }
    }
    var generateOutput = function () { }; //defined later, but should be a noop until ready
    if (config.width > $(".main-image").width()) {
        setTimeout(function () {
            $('.main-image').css({ position: '', width: '' });
        }, 350);
        $(".main-image").css({
            position: 'absolute',
            width: config.width + "px"
        });
    }
    // parentDiv.append("<canvas id='ds-canvas-"+studio_id+"' height='"+config.height+"' width='"+config.width+"'>");
    parentDiv.append("<div style='width:" + config.width + "px;height:" + config.height + "px;' id='design_studio_canvases_" + studio_id + "' class='design_studio_canvasses' />");
    parentDiv.append("<div class='ds-instructions'><p style='text-align: center'>CUSTOMIZE YOUR COLORS BELOW</p></div>")
    // parentDiv.append("<div class='ds-instructions'><p>CUSTOMIZE YOUR COLORS BELOW <a class='ds-video_link' href='youtubelinkgoeshere' target='_blank'>WATCH HOW-TO</a></p></div>")
    // parentDiv.append("<h2>Set all colors to one of our&nbsp;colorways.</h2>");


    $("#divOptionsBlock").find("select").each(function () {
        var label = $.trim($(this).closest('.opt-regular').find('.label').text());
        labelToSelect[label] = $.trim($(this).prop('name'));
    });
    $("#divOptionsBlock").find("input[type=text],textarea").each(function () {
        var label = $.trim($(this).closest('.opt-field').find('label').text());
        labelToText[label] = $.trim($(this).prop('name'));
    });

    function imageLayer(layerIdx) {

        var layer = config.layers[layerIdx];
        // Some sanity checks
        if (typeof layer.src != 'string') {
            if (typeof layer.select_label == undefined) {
                throw "Layer " + layer.id + " provided a list for the src but did not provide a select box to key off of.";
            }
            if (typeof labelToSelect[layer.select_label] == 'undefined') {
                throw "Could not find select label " + layer.select_label + ". The following are the labels we know about:\n" + Object.keys(labelToSelect);
            }
            $(document).on('change', "select[name=" + labelToSelect[layer.select_label] + "]", function () {
                raster.source = findImage();
            });
        }
        var canvas_id = "ds-canvas-" + studio_id + "-" + layer.id;
        $("#design_studio_canvases_" + studio_id).append("<canvas id='ds-canvas-" + studio_id + "-" + layer.id + "' height='" + config.height + "' width='" + config.width + "'>");
        var scope = new paper.PaperScope();
        var localScope = scope.setup(document.getElementById(canvas_id));
        var that = this;
        // var listItem;

        if (layer.src && isArray(layer.src)) {
            var srcObj = {};
            var child = 0;
            $("select[name=" + labelToSelect[layer.select_label] + "]").children().each(function () {
                srcObj[$(this).prop('value')] = layer.src[child++];
            });
            layer.src = srcObj;
        }

        // Do we have a toggle select?
        var toggleSelect = function (isOn) {
            //noop
        };
        if (layer.toggleSelectLabel) {
            if (!layer.toggleable) {
                console.error("A toggleSelectLabel was found, but this layer is not toggleable.");
            } else {
                if (typeof layer.toggleSelectLabel == 'string') {
                    layer.toggleSelectLabel = [layer.toggleSelectLabel];
                }
                var getToggledOn = function () {
                    for (var togIdx = 0; togIdx < layer.toggleSelectLabel.length; togIdx++) {
                        var tog = layer.toggleSelectLabel[togIdx];
                        if (toggledOptions[tog.label][$("select[name=" + labelToSelect[tog.label] + "]").val()]) {
                            return true;
                        }
                    }
                    return false;
                };
                var toggledOptions = {};
                var extractName = function (name) {
                    return $.trim(name.match(/^[a-zA-Z0-9 \/]+/)[0])
                };
                for (var togIdx = 0; togIdx < layer.toggleSelectLabel.length; togIdx++) {
                    var tog = layer.toggleSelectLabel[togIdx];
                    if (typeof tog == 'string') {
                        tog = {
                            label: tog
                        };
                        layer.toggleSelectLabel[togIdx] = tog;
                    }
                    if (tog.onIf) {
                        $("select[name=" + labelToSelect[tog.label] + "]").children().each(function () {
                            var thisVal = extractName($(this).text());
                            if (!toggledOptions[tog.label]) {
                                toggledOptions[tog.label] = {};
                            }
                            if (tog.onIf.indexOf(thisVal) > -1) {
                                toggledOptions[tog.label][$(this).prop('value')] = true;
                            } else {
                                toggledOptions[tog.label][$(this).prop('value')] = false;
                            }
                        });
                    } else {
                        var lastVal = true;
                        $("select[name=" + labelToSelect[tog.label] + "]").children().each(function () {
                            lastVal = !lastVal;
                            if (!toggledOptions[tog.label]) {
                                toggledOptions[tog.label] = {};
                            }
                            toggledOptions[tog.label][$(this).prop('value')] = lastVal;
                        });
                    }
                    $(document).on('change', "select[name=" + labelToSelect[tog.label] + "]", function () {
                        layer.toggledOn = getToggledOn();
                        that.setToggle();
                    });
                }
                toggleSelect = function (isOn) {
                    for (var option in toggledOptions) {
                        if (!toggledOptions.hasOwnProperty(option)) {
                            continue;
                        }
                        for (var val in toggledOptions[option]) {
                            if (!toggledOptions[option].hasOwnProperty(val)) {
                                continue;
                            }
                            if (toggledOptions[option][val] == isOn) {
                                $("select[name=" + labelToSelect[option] + "]").val(val);
                            }
                        }
                    }
                };

            }
        }

        this.injectToggle = function (isOn) {
            layer.toggledOn = isOn;
            toggleSelect(isOn);
        };

        var findImage = function () {
            if (typeof layer.src == 'string') {
                return layer.src;
            }
            // The only other option is a list, let's find the dropdown box. Default to the first item on the list
            var labelKey = $("select[name=" + labelToSelect[layer.select_label] + "]").val();
            if (layer.src[labelKey] == undefined) {
                console.error("We could not find an image for " + layer.id + " with the key " + labelKey + ", using the first image as a fallback.");
                for (var idx in layer.src) {
                    if (!layer.src.hasOwnProperty(idx)) {
                        continue;
                    }
                    return layer.src[idx];
                }
            }
            return layer.src[labelKey];
        };
        this.setColor = function (localColor, fromColorway) {
            localColor = localColor || color;
            if (layer.color_condition != undefined) {
                //This overrides anything you send it
                localColor = conditionalColor();
            }
            color = localColor;
            scope.activate();
            if (!fromColorway && layer.colorable) {
                setColorwayColor(layer.colorwayNum, localColor, true);
            }
            if (layer.colorFrom && config.layers[layersToIdx[layer.colorFrom]] && config.layers[layersToIdx[layer.colorFrom]].bin) {
                localColor = config.layers[layersToIdx[layer.colorFrom]].bin.getColor();
                layer.toggledOn = config.layers[layersToIdx[layer.colorFrom]].toggledOn;
                if (layer.border) {
                    localBorderColor = config.layers[layersToIdx[layer.colorFrom]].bin.getColor(true);
                }
            }
            if (layer.toggleable && layer.offIfColorMatches) {
                var remoteColor;
                if (config.layers[layersToIdx[layer.offIfColorMatches.toLowerCase()]]) {
                    remoteColor = config.layers[layersToIdx[layer.offIfColorMatches.toLowerCase()]].bin.getColor();
                    if (color == remoteColor) {
                        layer.toggleCondition = false;
                    } else {
                        layer.toggleCondition = true;
                    }

                } else {
                    setColorCallback(layer.offIfColorMatches.toLowerCase(), layer.id);
                }
                this.setToggle();
            } else {
                layer.toggleCondition = true;
            }
            localColor = Colorama(colorFromSwatch(localColor));
            // scope.view._viewsById[canvas_id]._project.activate();
            overlay.fillColor = "#" + localColor.hex();
            scope.project._view.draw();
            if (remoteColors[layer.id] != undefined) {
                for (var condIdx = 0; condIdx < remoteColors[layer.id].length; condIdx++) {
                    if (!isArray(remoteColors[layer.id])) {
                        remoteColors[layer.id] = [remoteColors[layer.id]];
                    }
                    for (var remIdx = 0; remIdx < remoteColors[layer.id].length; remIdx++) {
                        config.layers[layersToIdx[remoteColors[layer.id][remIdx]]].bin.setColor(undefined, false);
                    }
                }
            }
            generateOutput();
        };
        this.getColor = function () {
            return color;
        };
        var conditionalColor = function () {
            //This should only be called if color_condition is set
            //Use the first condition that matches
            for (var condIdx = 0; condIdx < layer.color_condition.length; condIdx++) {
                for (var localCondIdx = 0; localCondIdx < layer.color_condition[condIdx].conditions.length; localCondIdx++) {
                    if (layer.color_condition[condIdx].conditions[localCondIdx].target_color.indexOf(config.layers[layersToIdx[layer.color_condition[condIdx].conditions[localCondIdx].target]].bin.getColor()) > -1) {
                        return layer.color_condition[condIdx].color;
                    }
                }
            }
            console.warn("could not find a color for " + layer.id + ", sending white instead");
        };
        this.setToggle = function () {
            if (layer.toggleFrom && config.layers[layersToIdx[layer.toggleFrom]]) {
                layer.toggledOn = config.layers[layersToIdx[layer.toggleFrom]].toggledOn;
            }
            var isOn = layer.toggleCondition && layer.toggledOn;
            if (isOn) {
                $("#colorway_id-" + layer.id).find('.colorway-status').removeClass('colorway-off').addClass('colorway-on').text('ON').closest('.colorway-container').removeClass('colorway-off');
                raster.opacity = 1;
            } else {
                $("#colorway_id-" + layer.id).find('.colorway-status').removeClass('colorway-on').addClass('colorway-off').text('OFF').closest('.colorway-container').addClass('colorway-off');
                raster.opacity = 0;
            }
            toggleSelect(isOn);
            scope.project._view.draw();
            if (remoteColors[layer.id] != undefined) {
                for (var condIdx = 0; condIdx < remoteColors[layer.id].length; condIdx++) {
                    if (!isArray(remoteColors[layer.id])) {
                        remoteColors[layer.id] = [remoteColors[layer.id]];
                    }
                    for (var remIdx = 0; remIdx < remoteColors[layer.id].length; remIdx++) {
                        if (config.layers[layersToIdx[remoteColors[layer.id][remIdx]]].toggleable) {
                            config.layers[layersToIdx[remoteColors[layer.id][remIdx]]].bin.setToggle();
                        }
                    }
                }
            }
            generateOutput();
        };
        this.boxOutput = function () {
            var suffix = (layer.outputName) ? " " + $.trim(layer.outputName) : "";
            var retColor = (layer.toggledOn && layer.toggleCondition) || !layer.toggleable ? color : "No";
            return retColor + suffix;
        };
        this.saveOutput = function () {
            return {
                default_color: color,
                toggledOn: layer.toggledOn
            };
        };
        if (layer.outputLine != undefined) {
            if (outputLocations[layer.outputLine] == undefined) {
                outputLocations[layer.outputLine] = [];
            }
            outputLocations[layer.outputLine][layer.outputPos] = layerIdx;
        }

        var color;
        if (layer.default_color != undefined) {
            color = layer.default_color;
        }
        if (layer.color_condition != undefined) {
            var targets = {};
            for (var condIdx = 0; condIdx < layer.color_condition.length; condIdx++) {
                for (var localCondIdx = 0; localCondIdx < layer.color_condition[condIdx].conditions.length; localCondIdx++) {
                    targets[layer.color_condition[condIdx].conditions[localCondIdx].target] = 1;
                }
            }
            targets = Object.keys(targets);
            for (var condIdx = 0; condIdx < targets.length; condIdx++) {
                if (remoteColors[targets[condIdx]] == undefined) {
                    remoteColors[targets[condIdx]] = [];
                }
                remoteColors[targets[condIdx]].push(layer.id);
            }
            color = conditionalColor();
        }
        if (layer.colorFrom != undefined) {
            layer.colorFrom = layer.colorFrom.toLowerCase();
            if (remoteColors[layer.colorFrom] == undefined) {
                remoteColors[layer.colorFrom] = [];
            }
            remoteColors[layer.colorFrom].push(layer.id);
        }
        if (layer.toggleFrom != undefined) {
            layer.toggleFrom = layer.toggleFrom.toLowerCase();
            if (remoteColors[layer.toggleFrom] == undefined) {
                remoteColors[layer.toggleFrom] = [];
            }
            remoteColors[layer.toggleFrom].push(layer.id);
        }

        var raster = new paper.Raster(findImage());
        raster.position = paper.view.center;
        var overlay;
        if (color) {
            overlay = new paper.Path.Rectangle(paper.view.bounds);
            overlay.blendMode = "source-in";
            this.setColor(color, true);
        }

        // Set up the colorways...
        if (layer.colorable) {
            var maybeToggle = (layer.toggleable) ? '<span class="colorway-status colorway-on">ON</span>' : '';
            $('#colorways_header_' + studio_id).after("<div id='colorway_id-" + layer.id + "' class='colorway-container text-" + color + "' data-id='" + colorwayNum + "'><p><span class='colorway-swatch bg-" + color + "'>&nbsp;</span>&nbsp;" + layer.label + "&nbsp;" + maybeToggle + "</p></div>");
            if (layer.toggleable) {
                $("#colorway_id-" + layer.id).find('.colorway-status').click(function (e) {
                    layer.toggledOn = !layer.toggledOn;
                    e.stopPropagation();
                    that.setToggle();
                });
            }
            colorwaysToLayers[colorwayNum] = layerIdx;
            layer.colorwayNum = colorwayNum;
            colorwayNum++;
        }
    }
    var textLayer = function (layerIdx) {
        var layer = config.layers[layerIdx];
        layer.toggleCondition = true;
        var canvas_id = "ds-canvas-" + studio_id + "-" + layer.id;
        $("#design_studio_canvases_" + studio_id).append("<canvas id='ds-canvas-" + studio_id + "-" + layer.id + "' height='" + config.height + "' width='" + config.width + "'>");
        var scope = new paper.PaperScope();
        var localScope = scope.setup(document.getElementById(canvas_id));
        var that = this;
        var textValue = "Sample";
        var currentFont;

        // Do we have a toggle select?
        var toggleSelect = function (isOn) {
            //noop
        };
        if (layer.toggleSelectLabel) {
            if (!layer.toggleable) {
                console.error("A toggleSelectLabel was found, but this layer is not toggleable.");
            } else {
                if (typeof layer.toggleSelectLabel == 'string') {
                    layer.toggleSelectLabel = [layer.toggleSelectLabel];
                }
                var getToggledOn = function (doOr) {
                    if (doOr) {
                        for (var togIdx = 0; togIdx < layer.toggleSelectLabel.length; togIdx++) {
                            var tog = layer.toggleSelectLabel[togIdx];
                            if (!toggledOptions[tog.label][$("select[name=" + labelToSelect[tog.label] + "]").val()]) {
                                return false;
                            }
                        }
                        return true;
                    }
                    for (var togIdx = 0; togIdx < layer.toggleSelectLabel.length; togIdx++) {
                        var tog = layer.toggleSelectLabel[togIdx];
                        if (toggledOptions[tog.label][$("select[name=" + labelToSelect[tog.label] + "]").val()]) {
                            return true;
                        }
                    }
                    return false;
                };
                var toggledOptions = {};
                var extractName = function (name) {
                    return $.trim(name.match(/^[a-zA-Z0-9 \/]+/)[0])
                };
                for (var togIdx = 0; togIdx < layer.toggleSelectLabel.length; togIdx++) {
                    var tog = layer.toggleSelectLabel[togIdx];
                    if (typeof tog == 'string') {
                        tog = {
                            label: tog
                        };
                        layer.toggleSelectLabel[togIdx] = tog;
                    }
                    if (tog.onIf) {
                        $("select[name=" + labelToSelect[tog.label] + "]").children().each(function () {
                            var thisVal = extractName($(this).text());
                            if (!toggledOptions[tog.label]) {
                                toggledOptions[tog.label] = {};
                            }
                            if (tog.onIf.indexOf(thisVal) > -1) {
                                toggledOptions[tog.label][$(this).prop('value')] = true;
                            } else {
                                toggledOptions[tog.label][$(this).prop('value')] = false;
                            }
                        });
                    } else {
                        var lastVal = true;
                        $("select[name=" + labelToSelect[tog.label] + "]").children().each(function () {
                            lastVal = !lastVal;
                            if (!toggledOptions[tog.label]) {
                                toggledOptions[tog.label] = {};
                            }
                            toggledOptions[tog.label][$(this).prop('value')] = lastVal;
                        });
                    }
                    $(document).on('change', "select[name=" + labelToSelect[tog.label] + "]", function () {
                        layer.toggledOn = getToggledOn();
                        that.setToggle();
                    });
                }
                // console.log(toggledOptions)
                toggleSelect = function (isOn) {
                    isOn = getToggledOn();
                    var hasCount = 0, toggledCount = 0;
                    for (var option in toggledOptions) {
                        if (!toggledOptions.hasOwnProperty(option)) {
                            continue;
                        }
                        if (toggledOptions[option][$("select[name=" + labelToSelect[option] + "]").val()] == isOn) {
                            break;
                        }
                        for (var val in toggledOptions[option]) {
                            if (!toggledOptions[option].hasOwnProperty(val)) {
                                continue;
                            }
                            if (toggledOptions[option][val] != undefined && toggledOptions[option][val] == isOn) {
                                $("select[name=" + labelToSelect[option] + "]").val(val);
                                break;
                            }
                        }
                    }
                };

            }
        }

        this.injectToggle = function (isOn) {
            layer.toggledOn = isOn;
            toggleSelect(isOn);
        };

        // Do we have a border with a toggle select?
        this.injectBorderToggle = function (isOn) {
            layer.border.toggledOn = isOn;
            toggleSelectBorder(isOn);
        };
        var toggleSelectBorder = function () {
            //noop
        };
        if (layer.border && layer.border.toggleSelectLabel) {
            if (!layer.border.toggleable) {
                console.error("A toggleSelectLabel was found on a border, but this border layer is not toggleable.");
            } else if (!labelToSelect[layer.border.toggleSelectLabel]) {
                console.error("Could not find select box with label " + layer.border.toggleSelectLabel);
            } else {
                var borderToggledOptions = {};
                var lastVal = true;
                $("select[name=" + labelToSelect[layer.border.toggleSelectLabel] + "]").children().each(function () {
                    lastVal = !lastVal;
                    borderToggledOptions[$(this).prop('value')] = lastVal;
                });
                toggleSelectBorder = function (isOn) {
                    for (var option in borderToggledOptions) {
                        if (!borderToggledOptions.hasOwnProperty(option)) {
                            continue;
                        }
                        if (borderToggledOptions[option] == isOn) {
                            $("select[name=" + labelToSelect[layer.border.toggleSelectLabel] + "]").val(option);
                            break;
                        }
                    }
                };
                $(document).on('change', "select[name=" + labelToSelect[layer.border.toggleSelectLabel] + "]", function () {
                    layer.border.toggledOn = borderToggledOptions[$(this).val()];
                    that.setToggle();
                    that.setColor();
                });
            }
        }


        this.setColor = function (localColor, fromColorway, localBorderColor) {
            localColor = localColor || color;
            localBorderColor = localBorderColor || borderColor;
            if (layer.color_condition != undefined) {
                //This overrides anything you send it
                localColor = conditionalColor();
            }
            if (layer.border && layer.border.color_condition != undefined) {
                localBorderColor = borderConditionalColor();
            }
            if (layer.colorFrom && config.layers[layersToIdx[layer.colorFrom]] && config.layers[layersToIdx[layer.colorFrom]].bin) {
                localColor = config.layers[layersToIdx[layer.colorFrom]].bin.getColor();
                layer.toggledOn = config.layers[layersToIdx[layer.colorFrom]].toggledOn;
                if (layer.border) {
                    localBorderColor = config.layers[layersToIdx[layer.colorFrom]].bin.getColor(true);
                }
            }
            color = localColor;
            borderColor = localBorderColor;
            scope.activate();
            if (!fromColorway && layer.colorable) {
                setColorwayColor(layer.colorwayNum, localColor, true, localBorderColor);
            }
            if (layer.toggleable && layer.offIfColorMatches) {
                var remoteColor;
                if (config.layers[layersToIdx[layer.offIfColorMatches.toLowerCase()]]) {
                    remoteColor = config.layers[layersToIdx[layer.offIfColorMatches.toLowerCase()]].bin.getColor();
                    if (color == remoteColor && !(layer.border && borderColor != remoteColor && layer.border.toggledOn)) {
                        layer.toggleCondition = false;
                    } else {
                        layer.toggleCondition = true;
                    }

                } else {
                    setColorCallback(layer.offIfColorMatches.toLowerCase(), layer.id);
                }
                this.setToggle();
            } else {
                layer.toggleCondition = true;
            }
            localColor = Colorama(colorFromSwatch(localColor));
            // scope.view._viewsById[canvas_id]._project.activate();
            text.fillColor = "#" + localColor.hex();
            if (layer.border) {
                localBorderColor = Colorama(colorFromSwatch(localBorderColor));


                if (layer.border.copyFrom && config.layers[layersToIdx[layer.border.copyFrom]] && config.layers[layersToIdx[layer.border.copyFrom]].bin) {
                    layer.border.toggledOn = config.layers[layersToIdx[layer.border.copyFrom]].bin.getBorderOn();
                }
                text.strokeColor = layer.border.toggledOn && (layer.border && color != borderColor) ? "#" + localBorderColor.hex() : null;
                if (layer.border.offIfColorMatches) {
                    remoteColor = config.layers[layersToIdx[layer.border.offIfColorMatches.toLowerCase()]].bin.getColor();
                    layer.border.toggleCondition = borderColor != remoteColor;
                } else {
                    layer.border.toggleCondition = true;
                }
                if (layer.border.toggleable) {
                    this.setToggle()
                }
            }
            scope.project._view.draw();
            if (remoteColors[layer.id] != undefined) {
                for (var condIdx = 0; condIdx < remoteColors[layer.id].length; condIdx++) {
                    if (!isArray(remoteColors[layer.id])) {
                        remoteColors[layer.id] = [remoteColors[layer.id]];
                    }
                    for (var remIdx = 0; remIdx < remoteColors[layer.id].length; remIdx++) {
                        config.layers[layersToIdx[remoteColors[layer.id][remIdx]]].bin.setColor(undefined, false);
                    }
                }
            }
            generateOutput();
        };
        this.setBounds = function () {
            if (layer.fontBounds) {
                var len = (textValue.length || 1) - 1;
                if (len >= layer.fontBounds.length) {
                    len = layer.fontBounds.length - 1;
                }
                layer.posX = layer.fontBounds[len].posX;
                layer.posY = layer.fontBounds[len].posY;
                bounds.bounds.width = layer.fontBounds[len].sizeX;
                bounds.bounds.height = layer.fontBounds[len].sizeY;
            }
            bounds.position.x = layer.posX;
            bounds.position.y = layer.posY;
            text.fitBounds(bounds.bounds);
            scope.project._view.draw();
        };
        this.getColor = function (isBorder) {
            if (isBorder) {
                return borderColor;
            }
            return color;
        };
        this.setBorder = function (toggledOn, remoteBorderColor) {
            layer.border.toggledOn = toggledOn;
            borderColor = remoteBorderColor;
            this.setColor();
            this.setToggle();
        };
        this.getBorderOn = function () {
            return borderIsOn;
        };
        var borderIsOn;
        this.setToggle = function () {
            var isOn = layer.toggleCondition && layer.toggledOn;
            var hasContent = !!textValue.length;
            if (isOn) {
                $("#colorway_id-" + layer.id).find('.colorway-status').removeClass('colorway-off').addClass('colorway-on').text('ON').closest('.colorway-container').removeClass('colorway-off');
                if (hasContent) {
                    text.opacity = 1;
                } else {
                    text.opacity = 0;
                }
            } else {
                $("#colorway_id-" + layer.id).find('.colorway-status').removeClass('colorway-on').addClass('colorway-off').text('OFF').closest('.colorway-container').addClass('colorway-off');
                text.opacity = 0;
            }
            if (!layer.passiveSwitch) {
                toggleSelect(isOn);
            }
            if (layer.border) {
                // We use the same toggleCondition as the main layer, but we can toggle it on or off independently

                var borderOn = layer.toggleCondition && layer.toggledOn && layer.border.toggledOn && layer.border.toggleCondition;
                borderIsOn = borderOn;
                if (borderOn) {
                    text.strokeWidth = 2;
                    text.strokeColor = (layer.border && color != borderColor) ? "#" + Colorama(colorFromSwatch(borderColor)).hex() : null;
                    $("#colorway_id-" + layer.id + "-border").find('.colorway-status').removeClass('colorway-off').addClass('colorway-on').text('ON').closest('.colorway-container').removeClass('colorway-off');
                } else {
                    text.strokeColor = null;
                    $("#colorway_id-" + layer.id + "-border").find('.colorway-status').removeClass('colorway-on').addClass('colorway-off').text('OFF').closest('.colorway-container').addClass('colorway-off');
                }
                if (remoteBorders[layer.id]) {
                    for (var borderId = 0; borderId < remoteBorders[layer.id].length; borderId++) {
                        if (config.layers[layersToIdx[remoteBorders[layer.id][borderId]]].bin) {
                            config.layers[layersToIdx[remoteBorders[layer.id][borderId]]].bin.setBorder(isOn, borderColor);
                        }
                    }
                }
                this.setFont();
                if (!layer.border.passiveSwitch) {
                    toggleSelectBorder(isOn && borderOn);
                }
            }
            scope.project._view.draw();
            generateOutput();
        };
        var conditionalColor = function () {
            //This should only be called if color_condition is set
            //Use the first condition that matches
            for (var condIdx = 0; condIdx < layer.color_condition.length; condIdx++) {
                for (var localCondIdx = 0; localCondIdx < layer.color_condition[condIdx].conditions.length; localCondIdx++) {
                    if (layer.color_condition[condIdx].conditions[localCondIdx].target_color.indexOf(config.layers[layersToIdx[layer.color_condition[condIdx].conditions[localCondIdx].target]].bin.getColor()) > -1) {
                        return layer.color_condition[condIdx].color;
                    }
                }
            }
            console.warn("could not find a color for " + layer.id + ", sending white instead");
            return "white";
        };
        var borderConditionalColor = function () {
            //This should only be called if we know for sure we have a border...
            //Note that borders can only reference top level layers
            for (var condIdx = 0; condIdx < layer.border.color_condition.length; condIdx++) {
                for (var localCondIdx = 0; localCondIdx < layer.border.color_condition[condIdx].conditions.length; localCondIdx++) {
                    if (layer.border.color_condition[condIdx].conditions[localCondIdx].target_color.indexOf(config.layers[layersToIdx[layer.border.color_condition[condIdx].conditions[localCondIdx].target]].bin.getColor()) > -1) {
                        return layer.border.color_condition[condIdx].color;
                    }
                }
            }
            console.warn("could not find a color for border " + layer.id + ", sending white instead");
            return "white";
        };
        var prevSquish = 1;
        this.setText = function (newText) {
            textValue = newText;
            if (newText.length) {
                text.content = newText;
            }
            if (layer.fontSquish) {
                var curLength = newText.length;
                if (newText.length > layer.fontSquish.length) {
                    curLength = layer.fontSquish.length;
                }
                var squish = layer.fontSquish[curLength - 1] || 1;
                // console.log("reset squish: ",(squish / prevSquish) * 1.11);

                if (squish != prevSquish) {
                    var vals = {
                        strokeColor: text.strokeColor,
                        content: newText,
                        fontFamily: text.fontFamily,
                        opacity: text.opacity,
                        fillColor: text.fillColor,
                        strokeSize: text.strokeSize
                    };
                    text.remove();
                    text = backupText.clone();
                    for (var val in vals) {
                        if (!vals.hasOwnProperty(val)) {
                            continue;
                        }
                        text[val] = vals[val];
                    }
                    text.scale(squish, 1);
                }
                prevSquish = squish;
            }
            this.setToggle();
            this.setBounds();
            generateOutput();
        };
        this.getPosition = function () {
            return {
                x: text.position.x,
                y: text.position.y
            };
        };
        this.getRotation = function () {
            return {
                rotate: text.rotation
            };
        };
        this.movePosition = function (x, y) {
            text.position.x = text.position.x + x;
            text.position.y = text.position.y + y;
            scope.project._view.draw();
        };
        this.moveRotate = function (deg) {
            text.rotation = text.rotation + deg;
            scope.project._view.draw();
        };
        this.beginDebug = function () {
            text.fillColor = new paper.Color(1, 0, 0);
        };
        this.getObj = function () {
            return text;
        };
        this.setFont = function (font) {
            font = font || currentFont;
            currentFont = font;
            if (layer.border && color == borderColor && layer.border.toggledOn) {
                text.fontFamily = config.borderFontToName[$.trim(font)];
            } else {
                text.fontFamily = config.fontToName[$.trim(font)];
            }
            this.setBounds();
            generateOutput();
        };

        this.boxOutput = function () {

            var output;
            var name = layer.outputName || layer.id;
            // console.log("boxed output! ",name,layer.outputName, layer.toggledOn, layer.toggleCondition);
            if (textValue.length == 0) {
                output = "No " + name + " No Content" + " (" + color + ")";
            } else if (layer.toggleable && !layer.toggleCondition) {
                output = "No " + name + " Color Match"
            } else if (layer.toggleable && !layer.toggledOn) {
                output = "No " + name + " Toggled Off";
            } else {
                var borderOutput = "";
                if (layer.border && layer.border.toggledOn) {
                    borderOutput = " Number, " + borderColor + " border ";
                }
                var letters = text.content;
                var content = "";
                if (layer.expandAmbiguousCharacters) {
                    for (var letterIdx = 0; letterIdx < letters.length; letterIdx++) {
                        switch (letters[letterIdx]) {
                            case "0":
                                content += "0";
                                break;
                            case "o":
                                content += "-small-letter-o-";
                                break;
                            case "O":
                                content += "-big-letter-O-";
                                break;
                            case "1":
                                content += "1";
                                break;
                            case "l":
                                content += "-small-letter-l-";
                                break;
                            case "L":
                                content += "-big-letter-L-";
                                break;
                            default:
                                content += letters[letterIdx];
                        }
                    }
                } else {
                    content = text.content;
                }
                var maybeColor = color ? color + " " : "";
                output = $.trim(maybeColor + borderOutput + currentFont + ' "' + content + '"')
            }
            return output;
        };
        this.saveOutput = function () {
            var output = {
                default_color: color,
                toggledOn: layer.toggledOn
            };
            if (layer.border) {
                output.border = {
                    default_color: borderColor,
                    toggledOn: layer.border.toggledOn
                }
            }
            return output;
        };
        if (layer.outputLine != undefined) {
            if (outputLocations[layer.outputLine] == undefined) {
                outputLocations[layer.outputLine] = [];
            }
            outputLocations[layer.outputLine][layer.outputPos] = layerIdx;
        }
        var color;
        var borderColor;
        if (layer.default_color != undefined) {
            color = layer.default_color;
        }
        if (layer.border && layer.border.default_color != undefined) {
            borderColor = layer.border.default_color;
        }
        if (layer.color_condition != undefined) {
            var targets = {};
            for (var condIdx = 0; condIdx < layer.color_condition.length; condIdx++) {
                for (var localCondIdx = 0; localCondIdx < layer.color_condition[condIdx].conditions.length; localCondIdx++) {
                    targets[layer.color_condition[condIdx].conditions[localCondIdx].target] = 1;
                }
            }
            targets = Object.keys(targets);
            for (var condIdx = 0; condIdx < targets.length; condIdx++) {
                if (remoteColors[targets[condIdx]] == undefined) {
                    remoteColors[targets[condIdx]] = [];
                }
                remoteColors[targets[condIdx]].push(layer.id);
            }
            color = conditionalColor();
        }
        if (layer.offIfColorMatches != undefined) {
            if (remoteColors[layer.offIfColorMatches.toLowerCase()] == undefined) {
                remoteColors[layer.offIfColorMatches.toLowerCase()] = [];
            }
            remoteColors[layer.offIfColorMatches.toLowerCase()].push(layer.id);
        }
        if (layer.colorFrom != undefined) {
            layer.colorFrom = layer.colorFrom.toLowerCase();
            if (remoteColors[layer.colorFrom] == undefined) {
                remoteColors[layer.colorFrom] = [];
            }
            remoteColors[layer.colorFrom].push(layer.id);
        }
        if (layer.border && layer.border.copyFrom) {
            layer.border.copyFrom = layer.border.copyFrom.toLowerCase();
            if (remoteBorders[layer.border.copyFrom] == undefined) {
                remoteBorders[layer.border.copyFrom] = [];
            }
            remoteBorders[layer.border.copyFrom].push(layer.id);
        }
        var text = new paper.PointText(new paper.Point(layer.posX, layer.posY));
        text.justification = 'center';
        text.fontSize = 100;
        // text.position.x = layer.posX;
        // text.position.y = layer.posY;
        // text.strokeWidth = .3;
        text.strokeColor = 'green';
        if (layer.rotate) {
            text.rotate(layer.rotate);
        }
        var backupText = text.clone();
        backupText.opacity = 0;
        var bounds = new paper.Path.Rectangle({
            point: [layer.posX, layer.posY],
            size: [layer.sizeX, layer.sizeY]
        });


        this.setText('sample');
        this.setColor(color, true);
        if (!labelToText[layer.select_label]) {
            console.error("Could not find label " + layer.select_label);
        } else {
            that.setText($("input[name=" + labelToText[layer.select_label] + "]").val());
            $('body').on('keyup', "input[name=" + labelToText[layer.select_label] + "]", function () {
                that.setText($(this).val());
            });
            $('body').on('keyup', "textarea[name=" + labelToText[layer.select_label] + "]", function () {
                // that.setText($(this).val());
                // generateOutput();
                // console.log($(this).val());
            });
        }
        if (!labelToSelect[layer.font_label]) {
            console.error("Could not find label " + layer.font_layer);
        } else {
            that.setFont($("select[name=" + labelToSelect[layer.font_label] + "]").find(':selected').text());
            $("body").on('change', "select[name=" + labelToSelect[layer.font_label] + "]", function () {
                that.setFont($("select[name=" + labelToSelect[layer.font_label] + "]").find(':selected').text());
            });
            if (config.fontToName[$.trim($("select[name=" + labelToSelect[layer.font_label] + "]").find(':selected').text())]) {
                fontSpy(config.fontToName[$.trim($("select[name=" + labelToSelect[layer.font_label] + "]").find(':selected').text())], {
                    glyphs: "123abc",
                    success: function () {
                        that.setFont($("select[name=" + labelToSelect[layer.font_label] + "]").find(':selected').text());
                    },
                    failure: function () {
                        console.error("Could not set font because it could not be loaded. A system default font will be used instead.");
                    }
                });
            }
        }

        // Set up the colorways...
        if (layer.colorable) {
            var maybeToggle = (layer.toggleable) ? '<span class="colorway-status colorway-on">ON</span>' : '';
            $('#colorways_header_' + studio_id).after("<div id='colorway_id-" + layer.id + "' class='colorway-container text-" + color + "' data-id='" + colorwayNum + "'><p><span class='colorway-swatch bg-" + color + "'>&nbsp;</span>&nbsp;" + layer.label + "&nbsp;" + maybeToggle + "</p></div>");
            colorwaysToLayers[colorwayNum] = layerIdx;
            layer.colorwayNum = colorwayNum;
            if (layer.toggleable) {
                $("#colorway_id-" + layer.id).find('.colorway-status').click(function (e) {
                    layer.toggledOn = !layer.toggledOn;
                    if (!layer.toggledOn) {
                        e.stopPropagation();
                    }
                    that.setToggle();
                });
            }
            colorwayNum++;
            this.setToggle();
        }
        if (layer.border && layer.border.colorable) {
            var maybeToggle = (layer.border.toggleable) ? '<span class="colorway-status colorway-on">ON</span>' : '';
            $('#colorways_header_' + studio_id).after("<div id='colorway_id-" + layer.id + "-border' class='colorway-container text-" + borderColor + "' data-id='" + colorwayNum + "'><p><span class='colorway-swatch border-" + borderColor + "'>&nbsp;</span>&nbsp;" + layer.border.label + "&nbsp;" + maybeToggle + "</p></div>");
            colorwaysToLayers[colorwayNum] = layerIdx;
            layer.border.colorwayNum = colorwayNum;
            if (layer.border.toggleable) {
                $("#colorway_id-" + layer.id + "-border").find('.colorway-status').click(function (e) {
                    layer.border.toggledOn = !layer.border.toggledOn;
                    if (!layer.border.toggledOn) {
                        e.stopPropagation();
                    }
                    that.setToggle();
                    that.setColor();
                });
            }
            colorwayNum++;
            this.setToggle();
            if (config.borderFontToName[$.trim($("select[name=" + labelToSelect[layer.font_label] + "]").find(':selected').text())]) {
                fontSpy(config.borderFontToName[$.trim($("select[name=" + labelToSelect[layer.font_label] + "]").find(':selected').text())], {
                    glyphs: "123abc",
                    success: function () {
                        that.setFont($("select[name=" + labelToSelect[layer.font_label] + "]").find(':selected').text());
                    },
                    failure: function () {
                        console.error("Could not set font because it could not be loaded. A system default font will be used instead.");
                    }
                });
            }
        }
    };
    if (config.logoNameWarning) {
        window.nameWarningSingleton = makeid();
        $("body").append('<div id="ds-logo_option_name" class="ds-popup ds-popup-hide">'
        + '    <p>You\'ve chosen a <strong>logo option with no name</strong> but you\'ve provided us with your <strong>rider&nbsp;name.</strong></p>'
        + '<ul>'
        + '<li><span id="ds-logo_option_name-remove">Add name to AMA logo banner.</span></li>'
        + '<li><span id="ds-logo_option_name-add_side">Put name on side plates instead.</span></li>'
        + '<li><span id="ds-popup-meh_option">Remove name entirely.</span></li>'
        + '</ul></div>');
        var localSingleton = window.nameWarningSingleton;
        var swapLogo = function () {

        };
        $("#ds-logo_option_name-add_side").click(function () {
            $("#ds-logo_option_name").addClass('ds-popup-hide');

            for (var option in mapToggleOptions) {
                if (!mapToggleOptions.hasOwnProperty(option)) {
                    continue;
                }
                if (mapToggleOptions[option]) {
                    $("select[name=" + labelToSelect[config.logoNameWarning.nameToggleLabel] + "]").val(option);
                    $("select[name=" + labelToSelect[config.logoNameWarning.nameToggleLabel] + "]").change();
                }
            }

        });
        $("#ds-logo_option_name-remove").click(function () {
            $("#ds-logo_option_name").addClass('ds-popup-hide');
            if (logoId.toLowerCase() == 'none') {
                for (logoId in config.logoNameWarning.nonamesToNames) {
                    if (!config.logoNameWarning.nonamesToNames.hasOwnProperty(logoId)) {
                        continue;
                    }
                    break; //the first one we find will do
                }
            }
            $("select[name=" + labelToSelect[config.logoNameWarning.logoLabel] + "]").val(logosToKeys[config.logoNameWarning.nonamesToNames[logoId]]).change();
        });
        $("#ds-popup-meh_option").click(function () {
            $("#ds-logo_option_name").addClass('ds-popup-hide');
            $("input[name=" + labelToText[config.logoNameWarning.nameLabel] + "]").val("").change();
        });
        var logoId;
        var checkLogoWarning = function () {
            if (localSingleton != window.nameWarningSingleton) {
                return;
            }
            var hasName = !!$.trim($("input[name=" + labelToText[config.logoNameWarning.nameLabel] + "]").val()).length;
            var sideplatesHasName = mapToggleOptions[$("select[name=" + labelToSelect[config.logoNameWarning.nameToggleLabel] + "]").val()];
            logoId = $.trim(keysToLogos[$("select[name=" + labelToSelect[config.logoNameWarning.logoLabel] + "]").val()]);
            // if(logoId.toLowerCase() == "none"){
            //     return; // nothing to do!
            // }
            var logoHasName = !!namesToNonames[logoId] || logoId.toLowerCase() == 'none';
            if (hasName && !logoHasName && !sideplatesHasName) {
                $("#ds-logo_option_name").removeClass('ds-popup-hide');
                $("input[name=" + labelToText[config.logoNameWarning.nameLabel] + "]").closest('.opt-field').removeClass('alert');
            } else if (!hasName && sideplatesHasName && logoHasName) {
                $("input[name=" + labelToText[config.logoNameWarning.nameLabel] + "]").closest('.opt-field').addClass('alert');
            } else {
                $("input[name=" + labelToText[config.logoNameWarning.nameLabel] + "]").closest('.opt-field').removeClass('alert');
            }
        };
        var keysToLogos = {};
        var logosToKeys = {};
        var namesToNonames = {};
        var canContinue = true;
        var mapToggleOptions = {};
        if (!labelToSelect[config.logoNameWarning.logoLabel]) {
            canContinue = false;
            console.error("Could not find logo label " + config.logoNameWarning.logoLabel + " for the name warning");
        }
        if (!labelToText[config.logoNameWarning.nameLabel]) {
            canContinue = false;
            console.error("Could not find name label " + config.logoNameWarning.nameLabel + " for the name warning");
        }
        if (!labelToSelect[config.logoNameWarning.nameToggleLabel]) {
            canContinue = false;
            console.error("Could not find name toggle label " + config.logoNameWarning.nameToggleLabel + " for the name warning");
        }
        if (canContinue) {
            var lastVal = true;
            $("select[name=" + labelToSelect[config.logoNameWarning.nameToggleLabel] + "]").children().each(function () {
                lastVal = !lastVal;
                mapToggleOptions[$(this).prop('value')] = lastVal;
            });
            $("select[name=" + labelToSelect[config.logoNameWarning.logoLabel] + "]").children().each(function () {
                var value = $(this).prop('value')
                var mytext = $.trim($(this).text().match(/^[0-9a-zA-Z \/]+/)[0]);
                keysToLogos[value] = mytext;
                logosToKeys[mytext] = value;
            });
            for (var logoIdx in config.logoNameWarning.nonamesToNames) {
                if (!config.logoNameWarning.nonamesToNames.hasOwnProperty(logoIdx)) {
                    continue;
                }
                namesToNonames[config.logoNameWarning.nonamesToNames[logoIdx]] = logoIdx;
            }
            $(document).on('change', "select[name=" + labelToSelect[config.logoNameWarning.logoLabel] + "]", checkLogoWarning);
            $(document).on('change', "select[name=" + labelToSelect[config.logoNameWarning.nameToggleLabel] + "]", checkLogoWarning);
            $("body").on('change', "input[name=" + labelToText[config.logoNameWarning.nameLabel] + "]", checkLogoWarning);
            $("body").on("keyup", "input[name=" + labelToText[config.logoNameWarning.nameLabel] + "]", function () {
                $(this).closest('.alert').removeClass('alert');
                checkLogoWarning();
            });
        }
    }
    if (localStorage && !localStorage.shownDSPopup) {
        var selector;
        if (labelToSelect[config.uniquePopup]) {
            selector = "select[name=" + labelToSelect[config.uniquePopup] + "]";
        } else if (labelToText[config.uniquePopup]) {
            selector = "input[name=" + labelToText[config.uniquePopup] + "]";
        } else if (config.uniquePopup != undefined) {
            console.error("variable uniquePopup was set but the label could not be found");
        }
        if (selector) {
            $('body').on('change', selector, function () {
                if (localStorage.shownDSPopup) {
                    return;
                }
                if ($.trim($(this).find(":selected").text()) == "None") {
                    return;
                }
                if (localStorage) {
                    localStorage.shownDSPopup = "1";
                }
                $("body").append('<div id="ds-name_side" class="ds-popup">'
                    + '<p>Your bike and design choices are unique. Our artists will professionally design your name to fit on your side&nbsp;plates.</p>'
                    + '<p><img src="/design_studio/name_on_side_plate.png" alt="" style="width: 100%" /></p>'
                    + '<ul>'
                    + '  <li class="ds-center"><span id="ds-name_side-confirm">Cool. Got it.</span></li>'
                    + '</ul>'
                    + '</div>'
                    + '</div>'
                );
                $('body').on('click', '#ds-name_side', function () {
                    $(this).addClass('ds-popup-hide');
                });
            });
        }
    }
    var colorCallbacks = {};
    var setColorCallback = function (targetLayer, sourceLayer) {
        if (!colorCallbacks[targetLayer]) {
            colorCallbacks[targetLayer] = [];
        }
        colorCallbacks[targetLayer].push(sourceLayer);
    };
    var runColorCallbacks = function (targetLayer) {
        if (colorCallbacks[targetLayer]) {
            for (var layerIdx = 0; colorCallbacks[targetLayer].length; layerIdx++) {

            }
        }
    };
    var setColorwayColor = function (colorwayIdx, color, internal, borderColor) {
        var isBorder = false;
        var layerIdx = colorwaysToLayers[colorwayIdx];
        var maybeSuffix = "";
        if (config.layers[layerIdx].border && config.layers[layerIdx].border.colorwayNum == selected_colorway) {
            isBorder = true;
            color = borderColor || color;
            maybeSuffix = "-border";
        }
        $("#colorway_id-" + config.layers[colorwaysToLayers[colorwayIdx]].id + maybeSuffix).removeClass(function (index, css) {
            return (css.match(/(^|\s)text-\S+/g) || []).join(' ');
        }).addClass("text-" + color);
        $("#colorway_id-" + config.layers[colorwaysToLayers[colorwayIdx]].id + maybeSuffix).find('.colorway-swatch').removeClass(function (index, css) {
            if (isBorder) {
                return (css.match(/(^|\s)border-\S+/g) || []).join(' ');
            } else {
                return (css.match(/(^|\s)bg-\S+/g) || []).join(' ');
            }
        }).addClass((isBorder ? 'border-' : 'bg-') + color);
        if (!internal) {
            if (isBorder) {
                config.layers[layerIdx].bin.injectBorderToggle(true);
                config.layers[colorwaysToLayers[colorwayIdx]].bin.setColor(undefined, true, color);
            } else {
                config.layers[layerIdx].bin.injectToggle(true);
                config.layers[colorwaysToLayers[colorwayIdx]].bin.setColor(color, true);
            }
        }
    };

    var setSelectedColorway = function (colorwayIdx) {
        selected_colorway = colorwayIdx;
        $(".colorway-selected").removeClass("colorway-selected");
        $(".swatch-selected").removeClass("swatch-selected");
        var layerIdx = colorwaysToLayers[colorwayIdx];
        var isBorder = false;
        config.layers[layerIdx].bin.injectToggle(true);
        config.layers[layerIdx].bin.setToggle();
        if (config.layers[layerIdx].border && config.layers[layerIdx].border.colorwayNum == selected_colorway) {
            isBorder = true;
        }
        var color = config.layers[layerIdx].bin.getColor(isBorder);
        $("#swatch-container-" + studio_id).find(".bg-" + color).addClass('swatch-selected');
        var maybeSuffix = (isBorder) ? "-border" : "";
        $("#colorway_id-" + config.layers[layerIdx].id + maybeSuffix).addClass("colorway-selected");
    };

    function debounce(func, wait, immediate) {
        var timeout;
        return function () {
            var context = this, args = arguments;
            var later = function () {
                timeout = null;
                if (!immediate) func.apply(context, args);
            };
            var callNow = immediate && !timeout;
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
            if (callNow) func.apply(context, args);
        };
    };

    var isArray = function (variable) {
        return variable.constructor === Array
    };

    for (var presetIdx = 0; presetIdx < config.presets.length; presetIdx++) {
        var presetCont = $("<div id='preset-id-" + presetIdx + "' class='colorway_preset-container'>" + config.presets[presetIdx].name + "</div>");
        var thisSwatch = $("<div class='colorway_preset-card' id='colorway_preset-card-" + presetIdx + "' data-id='" + presetIdx + "'></div>");
        for (var colorIdx = 0; colorIdx < config.presets[presetIdx].colors.length; colorIdx++) {
            thisSwatch.append($("<div class='colorway_preset-swatch bg-" + config.presets[presetIdx].colors[colorIdx] + "'></div>"))
        }
        thisSwatch.append($("<div class='ds-clear'></div>"));
        presetCont.append(thisSwatch);
        parentDiv.append(presetCont);
    }
    parentDiv.append("<h2 id='colorways_header_" + studio_id + "'>INDIVIDUAL COLORS</h2>");

    var swatchContainer = $("<div id='swatch-container-" + studio_id + "' class='swatch-container' />");
    for (var swatchIdx = 0; swatchIdx < config.swatches.length; swatchIdx++) {
        swatchContainer.append("<div id='swatch-" + config.swatches[swatchIdx] + "' class='swatch bg-" + config.swatches[swatchIdx] + "'><div class='swatch_name text-" + config.swatches[swatchIdx] + "'><p><span>" + config.swatchesToLabels[config.swatches[swatchIdx]] + "</span></p></div></div>");
    }
    parentDiv.append(swatchContainer);
    parentDiv.append($("<div class='ds-clear'></div>"));
    $(".main-image").prepend(parentDiv);

    // var canvas = document.getElementById("ds-canvas-"+studio_id);
    // paper.setup(canvas);
    // var scope = new paper.PaperScope();
    // console.log(scope);

    for (var layerIdx = 0; layerIdx < config.layers.length; layerIdx++) {
        if (layersToIdx[config.layers[layerIdx].id] != undefined) {
            throw "Duplicate layer id found: " + config.layers[layerIdx].id;
        }
        layersToIdx[config.layers[layerIdx].id] = layerIdx;
        if (config.layers[layerIdx].preset != undefined) {
            if (swatchToLayers[config.layers[layerIdx].preset] == undefined) {
                swatchToLayers[config.layers[layerIdx].preset] = [];
            }
            swatchToLayers[config.layers[layerIdx].preset].push(layerIdx);
        }
        switch (config.layers[layerIdx].type) {
            case "image":
                config.layers[layerIdx].bin = new imageLayer(layerIdx);
                break;
            case "text":
                config.layers[layerIdx].bin = new textLayer(layerIdx);
                break;
        }

        // if(config.layers[layerIdx].type == 'image') break;
    }

    // Restore preset labels in the form, and mark each one as changed
    if (savedConfig && savedConfig[config.namespace] && savedConfig[config.namespace].labels) {
        for (var label in savedConfig[config.namespace].labels) {
            if (!savedConfig[config.namespace].labels.hasOwnProperty(label)) {
                continue;
            }
            var setSelect = function (label) {
                if (labelToSelect[label]) {
                    $("select[name=" + labelToSelect[label] + "]").val(savedConfig[config.namespace].labels[label]);
                    $("select[name=" + labelToSelect[label] + "]").change();
                    setTimeout(function () {
                        $("select[name=" + labelToSelect[label] + "]").change();
                    }, Math.floor(Math.random() * 150) + 100);
                } else if (labelToText[label]) {

                    $("input[name=" + labelToText[label] + "],textarea[name=" + labelToText[label] + "]").val(savedConfig[config.namespace].labels[label]);
                    $("input[name=" + labelToText[label] + "],textarea[name=" + labelToText[label] + "]").keyup();
                    setTimeout(function () {
                        $("input[name=" + labelToText[label] + "],textarea[name=" + labelToText[label] + "]").keyup();
                    }, Math.floor(Math.random() * 150) + 100);
                }
            }
            setSelect(label);
        }
    }

    // for(var borderId in remoteBorders) {
    //     if(!remoteBorders.hasOwnProperty(borderId)) {
    //         continue;
    //     }
    //     layer.border = config.layers[layersToIdx[layer.copyFrom]].border;
    // }

    setSelectedColorway(colorwayNum - 1);

    //after all is done...
    paper.view.draw();

    $('canvas').css({
        '-webkit-user-select': '',
        'touch-action': '',
        '-webkit-user-drag': '',
        'webkit-tap-highlight-color': '',
        'height': ''
    });
    setTimeout(function () {
        $("select").change();
    }, 400);



    //Set up a few events...
    $("#design_studio_" + studio_id).on('click', ".colorway-container", function () {
        setSelectedColorway($(this).data('id'));
    });
    $("#swatch-container-" + studio_id).on('click', '.swatch', function () {
        $(".swatch-selected").removeClass('swatch-selected');
        $(this).addClass('swatch-selected');
        var color = $(this).prop('class').match(/(^|\s)bg-([a-z_-]+)/)[2];
        setColorwayColor(selected_colorway, color);
        paper.view.draw();
    });
    $("#design_studio_" + studio_id).on('click', '.colorway_preset-container', function () {
        var swatchIdx = $(this).children("div:first").data('id');
        for (var layerPresetIdx = 0; layerPresetIdx < config.presets[swatchIdx].colors.length; layerPresetIdx++) {
            if (swatchToLayers[layerPresetIdx] == undefined) {
                continue;
            }
            for (var swatchLayersIdx = 0; swatchLayersIdx < swatchToLayers[layerPresetIdx].length; swatchLayersIdx++) {
                config.layers[swatchToLayers[layerPresetIdx][swatchLayersIdx]].bin.setColor(config.presets[swatchIdx].colors[layerPresetIdx]);
            }
        }
    });

    // Build the human readable output

    if (config.writtenOutputLabel) {
        if (labelToText[config.writtenOutputLabel] == undefined) {
            console.error("Could not find output box for human readable version!");
        } else {
            $("textarea[name=" + labelToText[config.writtenOutputLabel] + "]").prop("readonly", true);

            generateOutput = debounce(function (skipStorage) {
                var output = [];
                var savable = {};
                for (var rowNum = 0; rowNum < outputLocations.length; rowNum++) {
                    var row = [];
                    for (var colNum = 0; colNum < outputLocations[rowNum].length; colNum++) {
                        row.push(config.layers[outputLocations[rowNum][colNum]].bin.boxOutput())
                    }
                    output.push(row.join(', '));
                }
                $("textarea[name=" + labelToText[config.writtenOutputLabel] + "]").val(output.join(", \n"));
                if (localStorage && !skipStorage) {
                    for (var layerNum = 0; layerNum < config.layers.length; layerNum++) {
                        savable[config.layers[layerNum].id] = config.layers[layerNum].bin.saveOutput();
                    }
                    savable.labels = {};
                    for (var labelIdx = 0; labelIdx < config.saveableLabels.length; labelIdx++) {
                        if (labelToSelect[config.saveableLabels[labelIdx]]) {
                            savable.labels[config.saveableLabels[labelIdx]] = $("select[name=" + labelToSelect[config.saveableLabels[labelIdx]] + "]").val();
                        } else if (labelToText[config.saveableLabels[labelIdx]]) {
                            savable.labels[config.saveableLabels[labelIdx]] = $("input[name=" + labelToText[config.saveableLabels[labelIdx]] + "],textarea[name=" + labelToText[config.saveableLabels[labelIdx]] + "]").val();
                        }
                    }
                    var savedConfig = {};
                    if (localStorage.dSSaved) {
                        try {
                            savedConfig = JSON.parse(localStorage.dSSaved)
                        } catch (e) {
                            console.log(e);
                            savedConfig = {};
                        }
                    }

                    savedConfig[config.namespace] = savable;
                    localStorage.dSSaved = JSON.stringify(savedConfig)
                }
                $("textarea[name=" + labelToText[config.writtenOutputLabel] + "]").prop("readonly", true);

            }, 200, false);
            setTimeout(generateOutput, 100);
            var bindTextBox = function (labelIdx) {
                var outputs = {
                    content: $("textarea[name=" + labelToText[config.saveableLabels[labelIdx]] + "]").val(),
                    focused: false
                };
                $("body").on('change', "textarea[name=" + labelToText[config.saveableLabels[labelIdx]] + "]", function () {
                    outputs.content = $("textarea[name=" + labelToText[config.saveableLabels[labelIdx]] + "]").val();
                    generateOutput();
                });
                $("body").on('focus', "textarea[name=" + labelToText[config.saveableLabels[labelIdx]] + "]", function () {
                    outputs.focused = true;
                });
                $("body").on('blur', "textarea[name=" + labelToText[config.saveableLabels[labelIdx]] + "]", function () {
                    outputs.focused = false;
                });
                setInterval(function () {
                    if (outputs.focused) return;
                    if ($("textarea[name=" + labelToText[config.saveableLabels[labelIdx]] + "]").val() == "" && outputs.content != "" && !outputs.focused) {
                        $("textarea[name=" + labelToText[config.saveableLabels[labelIdx]] + "]").val(outputs.content);
                    }
                }, 250);
            };
            for (var labelIdx = 0; labelIdx < config.saveableLabels.length; labelIdx++) {
                if (labelToText[config.saveableLabels[labelIdx]] == undefined) continue;
                bindTextBox(labelIdx);
            }
        }
        setInterval(function () {
            if (!$("textarea[name=" + labelToText[config.writtenOutputLabel] + "]").prop("readonly")) {
                generateOutput();
            }
        }, 1000);
    }


    // Simple util functions
    function makeid(len) {
        len = len || 5;
        var text = "";
        var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

        for (var i = 0; i < len; i++)
            text += possible.charAt(Math.floor(Math.random() * possible.length));

        return text;
    }

    function colorFromSwatch(swatch) {
        return $('.bg-' + swatch).css('background-color');
    }

    this.debug = function (id) {
        config.layers[layersToIdx[id]].bin.beginDebug();
        console.log(config.layers[layersToIdx[id]].bin.getPosition(), config.layers[layersToIdx[id]].bin.getRotation());
        console.log("Use your arrow keys to position the text. Each keypress represents 1 pixel. X and Y values will be displayed in the console.");
        $(document).on('keydown', function (e) {
            var tag = e.target.tagName.toLowerCase();
            if (tag != 'input' && tag != 'textarea') {
                switch (e.which) {
                    case 38:
                        config.layers[layersToIdx[id]].bin.movePosition(0, -1);
                        break;
                    case 40:
                        config.layers[layersToIdx[id]].bin.movePosition(0, 1);
                        break;
                    case 37:
                        config.layers[layersToIdx[id]].bin.movePosition(-1, 0);
                        break;
                    case 39:
                        config.layers[layersToIdx[id]].bin.movePosition(1, 0);
                        break;
                    case 81:
                        config.layers[layersToIdx[id]].bin.moveRotate(-1);
                        break;
                    case 69:
                        config.layers[layersToIdx[id]].bin.moveRotate(1);
                        break;
                    default:
                        return;
                }
                e.preventDefault();
                console.log(config.layers[layersToIdx[id]].bin.getPosition(), config.layers[layersToIdx[id]].bin.getRotation())
            }
        });
        return config.layers[layersToIdx[id]];
    }
}

$(document).ready(function () {
    if (window.designStudio == undefined) {
        window.designStudio = {
            push: function (initObj) {
                dS = new $ds(initObj);
                window.designStudio = [];
            }
        }
    } else {
        dS = new $ds(window.designStudio[0]);
    }
});
