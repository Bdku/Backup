jQuery(document).ready(function(){		
	/* mmenu */
	jQuery('nav#mmenu').mmenu();	
	jQuery('#owl-banner').owlCarousel({
		items:1,
		loop:true,
		nav:true,
		autoplay:true,
		autoplayTimeout: 6000,
		autoplaySpeed:2500
	});
	jQuery('#owl-testimonial').owlCarousel({
		items:1,
		loop:true,
		nav:false,
		dots:true,
		autoplay:true,
		autoplayTimeout: 6000,
		autoplaySpeed:2500
	});

	
	function close_accordion_section() {
		jQuery('.accordion').removeClass('active');
		jQuery('.panal').slideUp(300).removeClass('open');
	}
	jQuery('.accordion').click(function(e) {
		if(jQuery(e.target).is('.active')) {
			close_accordion_section();
		}else {
			close_accordion_section();
			jQuery(this).addClass('active');
			jQuery(this).next().slideDown(300);
		}
		e.preventDefault();
	});
	jQuery('.scrolTop').click(function(){
		jQuery("html, body").animate({ scrollTop: 0 }, 600);
		return false;
	});
	/* sticky */
	var target = jQuery('#headerWrapper').offset().top;

	    jQuery(window).scroll(function() {

	    if (jQuery(window).scrollTop() > target) {

	    jQuery('#headerWrapper').addClass('sticky');

	    } else {

	    jQuery('#headerWrapper').removeClass('sticky');       
	    }

	});	
});
(function(){
	var parallax = document.querySelectorAll(".parallax, .expertParallax"),
		speed = .5;
		window.onscroll = function(){
		[].slice.call(parallax).forEach(function(el,i){
		var windowYOffset = window.pageYOffset,
		elBackgrounPos = "50% " + (windowYOffset * speed) + "px";
		el.style.backgroundPosition = elBackgrounPos;
	});
};
})();


// Tab Options
$(function () {

    $('#login-form-link').click(function (e) {
        $("#login-form").delay(100).fadeIn(100);
        $("#register-form").fadeOut(100);
        $('#register-form-link').removeClass('active');
        $(this).addClass('active');
        e.preventDefault();
    });
    $('#register-form-link').click(function (e) {
        $("#register-form").delay(100).fadeIn(100);
        $("#login-form").fadeOut(100);
        $('#login-form-link').removeClass('active');
        $(this).addClass('active');
        e.preventDefault();
    });

});